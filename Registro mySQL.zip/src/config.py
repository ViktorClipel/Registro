MYSQL_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'bestiario_db'
}

SEMANTIC_SIMILARITY_THRESHOLD = 0.7